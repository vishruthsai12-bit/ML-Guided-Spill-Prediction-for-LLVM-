ML-Guided Spill Prediction for LLVM Register Allocation  -  IEEE Access LaTeX project
=====================================================================================

CONTENTS
  main.tex   full paper (text, 17 tables, 3 algorithms, 12 figures, 34 references,
             author biographies) in the same order as the Word file
  figs/      fig1.pdf ... fig12.pdf   (vector copies of the 12 figures, unchanged)
  photos/    a1.jpg ... a4.jpg        (author photos, unchanged)

IMPORTANT - the IEEE Access class file is NOT inside this zip
  main.tex uses  \documentclass{ieeeaccess}.  That class (ieeeaccess.cls + its logo
  files) is IEEE's own template and gives the blue headings, header, logo and
  two-column layout.  It is already built into Overleaf's "IEEE Access" template.

HOW TO RUN IN OVERLEAF  (recommended)
  1. Go to overleaf.com and log in.
  2. Open the IEEE Access template:  New Project -> Templates -> search "IEEE Access"
     -> "Open as Template".  (Or download "IEEE Access LaTeX template" from the IEEE
     Author Center and upload it as a new project.)  This gives you ieeeaccess.cls.
  3. Upload this project's files into that project:
        Menu / Upload icon -> upload the folders  figs  and  photos
        (keep the names exactly; the paths used are figs/figN.pdf and photos/aN.jpg)
  4. Replace the template's main .tex file with this main.tex:
        either upload main.tex (choose "Replace"), or open the template .tex file,
        delete everything and paste the whole content of main.tex.
  5. Menu (top-left) -> Settings:  Compiler = pdfLaTeX,  TeX Live version = 2023 or newer,
     Main document = main.tex  (or the name of the file you pasted into).
  6. Click Recompile.  Run it twice if cross-references/citations show "??".

ALTERNATIVE  (upload this zip directly)
  New Project -> Upload Project -> choose this zip.  Then upload ieeeaccess.cls and the
  other files that come with the IEEE Access template (logo images, .bst if included)
  into the project root.  Settings: pdfLaTeX, main document main.tex.

IF OVERLEAF SHOWS AN ERROR
  - "Undefined control sequence \history / \doi / \tfootnote / \corresp ..."
        you are not using the real ieeeaccess.cls -> repeat step 2.
  - File not found for figs/... or photos/...
        folders were not uploaded or were renamed -> repeat step 3.
  - Complaint about \titlepgskip   -> delete that one line in main.tex.
  - Complaint about \history{}     -> delete that one line in main.tex.

NOTES ON CONTENT
  - Corresponding-author lines (5 authors), 5 numbered affiliations, Funding footnote,
    DOI line and header "Vishruth Sai K et al.: ..." are as in the Word file.
  - The "Received/revised/accepted" history line is intentionally left empty.
  - Author Contributions, Funding, Competing Interests and Data and Code Availability
    come after the biographies, exactly as in the Word file.
